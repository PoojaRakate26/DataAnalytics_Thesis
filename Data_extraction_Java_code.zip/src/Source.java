
public class Source extends SourceSubClass {

	public static String retString() {
		return "Parent";
	}

	public static void main(String[] args) throws Exception {

		SourceSubClass s = new SourceSubClass();

		System.out.println(s.retString());

	}

}

class SourceSubClass {
	public static String retString() {
		return "Child";
	}
}