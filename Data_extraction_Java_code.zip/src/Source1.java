
public class Source1 {

	public static void main(String[] args) throws Exception {
		Source1 s1 = new Source1();
		s1.checkName("sasas","");
	}

	public String checkName(String firstName, String lastName) throws MyException {

		if (firstName.isEmpty() && lastName.isEmpty()) {
			throw new MyException();
		} else {
			return firstName + "" + lastName;
		}

	}
}

class MyException extends Exception {

}