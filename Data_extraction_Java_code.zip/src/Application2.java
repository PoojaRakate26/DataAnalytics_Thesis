import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;


//Class to remove all GIf DATA
public class Application2 {

	public String folderLocationWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\all_data_without_gif";
	public String trainFile = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train.txt";
	public String testFile = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_test.txt";
	public String trainFileWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train_WithoutGif.txt";
	public String testFileWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_test_WithoutGif.txt";
	ArrayList<String> linesToremove = new ArrayList<String>();

	public static void main(String[] args) {
		String folderLocation = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\all_data";

		Application2 a = new Application2();
		a.removeGifEntrysFromAllTextFilesFunctions(folderLocation);

		a.createNewTrainAndTestFilesWithoutGifData(a.linesToremove, a.testFile, a.testFileWithoutGif);
		a.createNewTrainAndTestFilesWithoutGifData(a.linesToremove, a.trainFile, a.trainFileWithoutGif);
	}

	public void removeGifEntrysFromAllTextFilesFunctions(String folderLocation) {
		try {
			ArrayList<File> allYogaFiles = this.getAllTextFilesInsideFolder(folderLocation);
			System.out.println(allYogaFiles);
			for (int i = 0; i < allYogaFiles.size(); i++) {
				this.checkAndRemoveGifEntry(allYogaFiles.get(i).getAbsolutePath(), allYogaFiles.get(i).getName());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<File> getAllTextFilesInsideFolder(String folderLocation) throws IOException {
		File folder = new File(folderLocation);
		File[] listOfFiles = folder.listFiles();
		ArrayList<File> filsesList = new ArrayList<File>();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".txt")) {
				filsesList.add(file);

				/*
				 * this.readFilesInsideFolder(file.getAbsolutePath().toString(),
				 * file.getName());
				 */

			}
		}
		return filsesList;
	}

	public void checkAndRemoveGifEntry(String fileLocation, String fileName) throws IOException {

		FileInputStream fis = new FileInputStream(fileLocation);
		Scanner sc = new Scanner(fis);
		ArrayList<String> linesToBeKeep = new ArrayList<String>();

		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] splittedLine = line.split("	");
			
			String validNameStrigns = line.replaceFirst("_/", "-").replaceFirst("/", "-");
			
			if (validNameStrigns.contains(".gif") || validNameStrigns.contains(".GIF")) {
				linesToremove.add(splittedLine[0].replaceFirst("_/", "-").replaceFirst("/", "-"));
			} else {

				linesToBeKeep.add(splittedLine[0].replaceFirst("_/", "-").replaceFirst("/", "-") +"	"+splittedLine[1]);
			}
		}
		this.createFileFromArraylistData(linesToBeKeep, folderLocationWithoutGif+"//"+fileName);

		sc.close();

	}

	public void createFileFromArraylistData(ArrayList<String> fileData, String fileName) {

		
		  if (fileData.size() != 0) { this.deleteOldFileIFExists(fileName); }
		 
		for (int i = 0; i < fileData.size(); i++) {
			try {

				FileWriter fw = new FileWriter(fileName, true); // the true will append the new data
				fw.write(fileData.get(i) + "\n");// appends the string to the file
				fw.close();

			} catch (IOException ioe) {
				System.err.println("IOException: " + ioe.getMessage());
			}
		}
		/* System.out.println("File Created" + fileName); */
	}

	public void createNewTrainAndTestFilesWithoutGifData(ArrayList<String> fileDataToRemove, String fileName, String newFile) {
		try {
			FileInputStream fis = new FileInputStream(fileName);
			Scanner sc = new Scanner(fis);
			ArrayList<String> dataToKeep = new ArrayList<String>();
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String validNameStrigns = line.replaceFirst("_/", "-").replaceFirst("/", "-").split(",")[0];

				if (fileDataToRemove.contains(validNameStrigns)) {
					System.out.println("REMOVE ******" + validNameStrigns);
				} else {
					dataToKeep.add(line.replaceFirst("_/", "-").replaceFirst("/", "-"));
				}
			}

			this.createFileFromArraylistData(dataToKeep, newFile);
			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteOldFileIFExists(String fileLocations) {
		Path path = Paths.get(fileLocations);
		try {

			Files.deleteIfExists(path);
		} catch (IOException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			
		}
	}

}
