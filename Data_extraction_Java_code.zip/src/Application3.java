import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Application3 {
	public String folderLocationWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\all_data_without_gif";
	public String trainFileWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train_WithoutGif.txt";
	public String testFileWithoutGif = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_test_WithoutGif.txt";
	public String image_download_not_found_404_400_train = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\image_download_not_found_404_400_train.txt";
	public String image_download_not_found_404_400_test = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\image_download_not_found_404_400_test.txt";
	public String image_downloaded_not_redable = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\image_downloaded_not_redable.txt";
	public String trainFileWithoutGif_new= "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train_WithoutGif_new.txt";
	public String testFileWithoutGif_new= "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_test_WithoutGif_new.txt";
	public String delete_entreis_from_main_test_data = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\New folder\\delete_entreis_from_main_train_data.txt";
	

	public static void main(String[] args) {
		Application3 a = new Application3();
		/*
		 * a.getFilesInsideFolder();
		 * a.readLinesInsideNotFound(a.image_download_not_found_404_400_train,
		 * a.trainFileWithoutGif, a.trainFileWithoutGif_new);
		 * a.readLinesInsideNotFound(a.image_download_not_found_404_400_test,
		 * a.testFileWithoutGif, a.testFileWithoutGif_new);
		 * System.out.println("------------------------FINISH------------------------");
		 */
		
		a.readLinesInsideNotFound(a.delete_entreis_from_main_test_data);
	}

	public void getFilesInsideFolder() {
		File folder = new File(folderLocationWithoutGif);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".txt")) {

				this.readFilesInsideFolder(file.getAbsolutePath().toString(), file.getName());

			}
		}
		
		
	}

	public void readFilesInsideFolder(String filePath, String fileExactName) {
		System.out.println(fileExactName);
		try {
			FileInputStream fis = new FileInputStream(filePath);

			Scanner sc = new Scanner(fis);

			ArrayList<ImageAndOutputCategoriesModel> traindData = this
					.readtrainOrTestData(fileExactName.replaceAll(".txt", ""), trainFileWithoutGif);
			ArrayList<ImageAndOutputCategoriesModel> testData = this
					.readtrainOrTestData(fileExactName.replaceAll(".txt", ""), testFileWithoutGif);
			
			System.out.println(traindData);
			System.out.println(testData);

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String[] details = line.split("	");
				String imageName = details[0];
				String imageUrl = details[1];

				

				if (traindData.stream().filter(o -> o.getImageName().equals(imageName)).findFirst().isPresent()) {
					Optional<ImageAndOutputCategoriesModel> model = traindData.stream().filter(o -> o.getImageName().equals(imageName)).findFirst();
					ImageAndOutputCategoriesModel data = model.get();
					this.saveImageFromUrlToFolder("TRAIN",data, imageUrl);
				} else if (testData.stream().filter(o -> o.getImageName().equals(imageName)).findFirst().isPresent()) {
					Optional<ImageAndOutputCategoriesModel> model = testData.stream().filter(o -> o.getImageName().equals(imageName)).findFirst();
					ImageAndOutputCategoriesModel data = model.get();
					this.saveImageFromUrlToFolder("TEST", data, imageUrl);
				} else {
					System.out.println(imageName + "-" + imageUrl);
					System.out.println("NOT FOUND");
				}

			}
			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ArrayList<ImageAndOutputCategoriesModel> readtrainOrTestData(String trainDataInitials,
			String trainOrTestDataUrl) {
		try {
			System.out.println(trainDataInitials+"---------------------"+trainOrTestDataUrl);

			ArrayList<ImageAndOutputCategoriesModel> trainOrTestData = new ArrayList<ImageAndOutputCategoriesModel>();

			FileInputStream fis = new FileInputStream(trainOrTestDataUrl);
			Scanner sc = new Scanner(fis);

			while (sc.hasNextLine()) {

				ImageAndOutputCategoriesModel model = new ImageAndOutputCategoriesModel();
				String line = sc.nextLine();
				if (line.contains(trainDataInitials)) {
					String[] data = line.split(",", 2);
					String imageName = data[0];
					model.imageName = imageName;
					model.level1 = Integer.parseInt(data[1].split(",")[0]);
					model.level2 = Integer.parseInt(data[1].split(",")[1]);
					model.level3 = imageName.split("-")[0];
					trainOrTestData.add(model);
				}
			}
			sc.close();
			return trainOrTestData;

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public void saveImageFromUrlToFolder(String testOrTrain, ImageAndOutputCategoriesModel model, String imageUrl) {
		
		URL url = null;
		try {
			url = new URL(imageUrl);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InputStream in;
		try {
			
			ImageUrls ig = this.generatePathsTosaveTheImage(model,testOrTrain);
			System.out.println(imageUrl+model.getImageName());
			
			File directory1 = new File(ig.getLevel1());
			File directory2 = new File(ig.getLevel2());
			File directory3 = new File(ig.getLevel3());
		    if (! directory1.exists()){
		        directory1.mkdirs();
		    }
		    if (! directory2.exists()){
		        directory2.mkdirs();
		    }
		    if (! directory3.exists()){
		        directory3.mkdirs();
		    }

			URLConnection connection = url.openConnection();
			connection.setReadTimeout(30000);
			in = new BufferedInputStream(connection.getInputStream());
			
			
			OutputStream out1 = new BufferedOutputStream(new FileOutputStream(ig.getLevel1()+ "//" +model.getImageName()));
			OutputStream out2 = new BufferedOutputStream(new FileOutputStream(ig.getLevel2()+ "//" +model.getImageName()));
			OutputStream out3 = new BufferedOutputStream(new FileOutputStream(ig.getLevel3()+ "//" +model.getImageName()));

			for (int i; (i = in.read()) != -1;) {
				out1.write(i);
				out2.write(i);
				out3.write(i);
			}
			in.close();
			
			out1.close();
			out2.close();
			out3.close();
			
			this.checkIfImageIsNullOrNot(ig.getLevel1()+ "\\" +model.getImageName(), model.getImageName(), imageUrl);
			
		} catch (IOException e) {
			this.AddEImageNotFoundEntry(model.getImageName()+" "+imageUrl+ " "+ e.getLocalizedMessage(), testOrTrain);
			 e.printStackTrace();
		} catch (Exception e) {
			this.AddEImageNotFoundEntry(model.getImageName()+" "+imageUrl+ " "+ e.getLocalizedMessage(), testOrTrain);
			e.printStackTrace();
		}

	}
	
	public ImageUrls generatePathsTosaveTheImage(ImageAndOutputCategoriesModel model, String testOrTrain) {
		ImageUrls ig = new ImageUrls();
		String level1Url = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\"+testOrTrain+"\\level_1\\"+model.level1;
		String level2Url = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\"+testOrTrain+"\\level_2\\"+model.level2;
		String level3Url = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\"+testOrTrain+"\\level_3\\"+model.level3;
		
		ig.setLevel1(level1Url);
		ig.setLevel2(level2Url);
		ig.setLevel3(level3Url);
		
		return ig;
		
		
	}
	
	public void AddEImageNotFoundEntry(String errorEntry, String trainOrTest) {
		try {
			String filename = "";
			if(trainOrTest == "TRAIN") {
				filename = image_download_not_found_404_400_train;
			}else {
				filename = image_download_not_found_404_400_test;
			}
			
			FileWriter fw = new FileWriter(filename, true); // the true will append the new data
			fw.write(errorEntry+ "\n");// appends the string to the file
			fw.close();
		} catch (IOException ioe) {
			System.err.println("IOException: " + ioe.getMessage());
		}

	}
	
	public void checkIfImageIsNullOrNot(String imageLocation, String imageName, String imagUrl) {
		BufferedImage img = null;

		try {
			img = ImageIO.read(new File(imageLocation)); // eventually
															// C:\\ImageTest\\pic2.jpg
			if (img == null) {
				String filename = image_downloaded_not_redable;
				FileWriter fw = new FileWriter(filename, true); // the true will append the new data
				fw.write(imageName+" "+" "+imagUrl +" " +imageLocation+"\n");// appends the string to the file
				fw.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void readLinesInsideNotFound(String errorFile, String trainOrTestFile, String newTrainOrTestFile) {
		try {

			FileInputStream fis = new FileInputStream(errorFile);
			Scanner sc = new Scanner(fis);
			ArrayList<String>notFoundImagesList = new ArrayList<String>();
			ArrayList<String>linesToKeep = new ArrayList<String>();

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				
				String [] notFoundImages =  line.split("\\*");
				notFoundImagesList.add(notFoundImages[0]);

			}
			System.out.println(notFoundImagesList);
			System.out.println(notFoundImagesList.size());
			
			sc.close();
			
			FileInputStream fisTrain = new FileInputStream(trainOrTestFile);
			Scanner scTrain = new Scanner(fisTrain);
			while (scTrain.hasNextLine()) {
				String line = scTrain.nextLine();
				String SpliiteLine = line.split(",")[0];
				
				if(notFoundImagesList.contains(SpliiteLine)) {
					System.out.println("TOREMOVE----------"+line);
				}else {
					
					linesToKeep.add(line);
				}

			}
			scTrain.close();
			
			for(int i=0;i<linesToKeep.size();i++) {
				try {
					String filename = newTrainOrTestFile;
					FileWriter fw = new FileWriter(filename, true); // the true will append the new data
					fw.write(linesToKeep.get(i) + "\n");// appends the string to the file
					fw.close();
				} catch (IOException ioe) {
					System.err.println("IOException: " + ioe.getMessage());
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void readLinesInsideNotFound(String fileName) {
		try {

			FileInputStream fis = new FileInputStream(fileName);
			Scanner sc = new Scanner(fis);
			ArrayList<String>notFoundImagesList = new ArrayList<String>();
			ArrayList<String>linesToKeep = new ArrayList<String>();

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				
				String [] notFoundImages =  line.split("D:")[0].split("http")[0].split(".jpg");
				notFoundImagesList.add(notFoundImages[0]);
			}
			System.out.println(notFoundImagesList);
			System.out.println(notFoundImagesList.size());
			
			sc.close();
			
			FileInputStream fisTrain = new FileInputStream("C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train_WithoutGif.txt");
			Scanner scTrain = new Scanner(fisTrain);
			while (scTrain.hasNextLine()) {
				String line = scTrain.nextLine();
				String SpliiteLine = line.split(".jpg")[0];
				System.out.println(SpliiteLine);
				
				if(notFoundImagesList.contains(SpliiteLine)) {
					System.out.println("TOREMOVE----------"+line);
				}else {
					
					linesToKeep.add(line);
				}

			}
			scTrain.close();
			
			
			for(int i=0;i<linesToKeep.size();i++) {
				try {
					String filename = "C:\\Local Disk D\\Pooja_Thesis\\2.0\\yoga_train_WithoutGif_new.txt";
					FileWriter fw = new FileWriter(filename, true); // the true will append the new data
					fw.write(linesToKeep.get(i) + "\n");// appends the string to the file
					fw.close();
				} catch (IOException ioe) {
					System.err.println("IOException: " + ioe.getMessage());
				}
			}
			 
			 

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
