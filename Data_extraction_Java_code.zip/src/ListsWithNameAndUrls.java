import java.util.ArrayList;

public class ListsWithNameAndUrls {

	ArrayList<String> allLinesInsideFIlesJustImages = new ArrayList<String>();
	ArrayList<String> allLinesInsideFIleswithUrl = new ArrayList<String>();
	public ArrayList<String> getAllLinesInsideFIlesJustImages() {
		return allLinesInsideFIlesJustImages;
	}
	public void setAllLinesInsideFIlesJustImages(ArrayList<String> allLinesInsideFIlesJustImages) {
		this.allLinesInsideFIlesJustImages = allLinesInsideFIlesJustImages;
	}
	public ArrayList<String> getAllLinesInsideFIleswithUrl() {
		return allLinesInsideFIleswithUrl;
	}
	public void setAllLinesInsideFIleswithUrl(ArrayList<String> allLinesInsideFIleswithUrl) {
		this.allLinesInsideFIleswithUrl = allLinesInsideFIleswithUrl;
	}
	
	
	
}
