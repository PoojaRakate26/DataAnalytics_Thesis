
public class ImageAndOutputCategoriesModel {

	String imageName;
	int level1;
	int level2;
	String level3;
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public int getLevel1() {
		return level1;
	}
	public void setLevel1(int level1) {
		this.level1 = level1;
	}
	public int getLevel2() {
		return level2;
	}
	public void setLevel2(int level2) {
		this.level2 = level2;
	}
	public String getLevel3() {
		return level3;
	}
	public void setLevel3(String level3) {
		this.level3 = level3;
	}
	@Override
	public String toString() {
		return "ImageAndOutputCategoriesModel [imageName=" + imageName + ", level1=" + level1 + ", level2=" + level2
				+ ", level3=" + level3 + "]";
	}
	
	
	
}
