import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Application {

	public static void main(String[] args) throws IOException {

		String folderLocation = "C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\folder0";

		Application a = new Application();
		/* a.getFilesInsideFolder(folderLocation); */
		String trainFolder = "C:\\Users\\Saurabh\\eclipse-workspace\\Pooja-Thesis\\Train";
		String testFolder = "C:\\Users\\Saurabh\\eclipse-workspace\\Pooja-Thesis\\Test";
		 a.readNullImagesFromTrainAndTest(trainFolder); 
		/*
		 * a.
		 * readLinesInsideNotFound("C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\Errors.txt"
		 * );
		 */

	}

	public void getFilesInsideFolder(String folderLocation) throws IOException {
		File folder = new File(folderLocation);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".txt")) {
				this.readFilesInsideFolder(file.getAbsolutePath().toString(), file.getName());

			}
		}
	}

	public void readFilesInsideFolder(String fileName, String fileExactName) throws IOException {

		FileInputStream fis = new FileInputStream(fileName);
		Scanner sc = new Scanner(fis);
		ArrayList<String> traindData = this.readTrainData(fileExactName.replaceAll(".txt", ""));
		ArrayList<String> testData = this.readTestData(fileExactName.replaceAll(".txt", ""));
		System.out.println(traindData);
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			String[] details = line.split("	");
			String imageName = details[0];
			String imageUrl = details[1];
			System.out.println(imageUrl);

			String replacedStr = imageName.replaceAll("_/", "-");
			String replacedStr1 = replacedStr.replaceAll("/", "-").replaceAll("'", "");
			System.out.println(replacedStr1);
			if (traindData.contains(replacedStr1)) {
				this.saveImageFromUrlToFolder(replacedStr1, imageUrl, "Train");
			} else if (testData.contains(replacedStr1)) {
				this.saveImageFromUrlToFolder(replacedStr1, imageUrl, "Test");
			} else {
				System.out.println("NOT FOUND");
			}
		}
		sc.close();

	}

	public void saveImageFromUrlToFolder(String imageName, String imageUrl, String folderName) {

		URL url = null;
		try {
			url = new URL(imageUrl);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InputStream in;
		try {

			URLConnection connection = url.openConnection();
			connection.setReadTimeout(30000);
			in = new BufferedInputStream(connection.getInputStream());

			OutputStream out = new BufferedOutputStream(new FileOutputStream(folderName + "//" + imageName));

			for (int i; (i = in.read()) != -1;) {
				out.write(i);
			}
			in.close();
			out.close();
		} catch (IOException e) {
			this.AddErrorEntry(imageName, imageUrl);
			e.printStackTrace();
		}

	}

	public void createeEwFile(String imageName) {

		File dir = new File("");
		File yourFile = new File("one.txt");

		/*
		 * try { yourFile.createNewFile(); FileOutputStream oFile = new
		 * FileOutputStream(yourFile, false); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } // if file already exists
		 * will do nothing
		 */

		File f = new File("C:\\Users\\Saurabh\\eclipse-workspace\\Pooja-Thesis\\Train\\" + imageName);
		if (!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.println("File already exists");
		}
	}

	public ArrayList<String> readTrainData(String trainDataInitials) {
		try {

			ArrayList<String> trainData = new ArrayList<String>();

			FileInputStream fis = new FileInputStream(
					"C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\yoga_train.txt");
			Scanner sc = new Scanner(fis);

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				if (line.contains(trainDataInitials)) {
					String[] data = line.split(",");
					String imageName = data[0];
					trainData.add(imageName);
				}
			}
			sc.close();
			return trainData;

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public ArrayList<String> readTestData(String testDataInitials) {
		try {

			ArrayList<String> testData = new ArrayList<String>();

			FileInputStream fis = new FileInputStream(
					"C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\yoga_test.txt");
			Scanner sc = new Scanner(fis);

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				if (line.contains(testDataInitials)) {
					String[] data = line.split(",");
					String imageName = data[0];
					testData.add(imageName);
				}
			}
			sc.close();
			return testData;

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public void AddErrorEntry(String imageName, String ImageUrl) {
		try {
			String filename = "C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\Errors.txt";
			FileWriter fw = new FileWriter(filename, true); // the true will append the new data
			fw.write(imageName + "***" + ImageUrl + "\n");// appends the string to the file
			fw.close();
		} catch (IOException ioe) {
			System.err.println("IOException: " + ioe.getMessage());
		}

	}

	public void readNullImagesFromTrainAndTest(String folderLocation) {

		File folder = new File(folderLocation);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".jpg")) {
				/*
				 * this.readFilesInsideFolder(file.getAbsolutePath().toString(),
				 * file.getName());
				 */
				this.checkIfImageIsNullOrNot(file.getAbsolutePath().toString(), file.getName().toString());
			}
		}

	}

	public void checkIfImageIsNullOrNot(String imageLocation, String imageName) {
		BufferedImage img = null;

		try {
			img = ImageIO.read(new File(imageLocation)); // eventually
															// C:\\ImageTest\\pic2.jpg
			if (img == null) {
				int lastIndexOfHyphen = imageLocation.lastIndexOf("-");
				String[] imageLocationSplit = { imageLocation.substring(0, lastIndexOfHyphen),
						imageLocation.substring(lastIndexOfHyphen) };
				String imagePathTillHyphen = imageLocationSplit[0];

				int lastIndexOfSlash = imagePathTillHyphen.lastIndexOf("\\");
				String[] imagePathTillHyphenSplit = { imagePathTillHyphen.substring(1, lastIndexOfSlash),
						imagePathTillHyphen.substring(lastIndexOfSlash + 1) };
				String fileName = imagePathTillHyphenSplit[1];
				ListsWithNameAndUrls allLinesInsideFIles = this.readFilesLinesInsideTheFile(fileName);

				if (allLinesInsideFIles.allLinesInsideFIlesJustImages.contains(imageName)) {
					int index = allLinesInsideFIles.allLinesInsideFIlesJustImages.indexOf(imageName);
					System.out.println(allLinesInsideFIles.allLinesInsideFIleswithUrl.get(index));
					this.AddImageNotFoundEntry(allLinesInsideFIles.allLinesInsideFIleswithUrl.get(index));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ListsWithNameAndUrls readFilesLinesInsideTheFile(String fileName) {
		try {
			ArrayList<String> allLinesInsideFIlesJustImages = new ArrayList<String>();
			ArrayList<String> allLinesInsideFIleswithUrl = new ArrayList<String>();
			ListsWithNameAndUrls lwu = new ListsWithNameAndUrls();

			FileInputStream fis = new FileInputStream(
					"C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\folder0\\" + fileName + ".txt");
			Scanner sc = new Scanner(fis);

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				String replacedStr = line.replaceFirst("_/", "-").replaceFirst("/", "-").replaceFirst("'", "");
				allLinesInsideFIlesJustImages.add(replacedStr.split("	")[0]);
				allLinesInsideFIleswithUrl.add(line);

			}
			sc.close();
			lwu.setAllLinesInsideFIlesJustImages(allLinesInsideFIlesJustImages);
			lwu.setAllLinesInsideFIleswithUrl(allLinesInsideFIleswithUrl);

			return lwu;

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public void AddImageNotFoundEntry(String data) {
		try {
			String filename = "C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\train-image-not-found.txt";
			FileWriter fw = new FileWriter(filename, true); // the true will append the new data
			fw.write(data + "\n");// appends the string to the file
			fw.close();
		} catch (IOException ioe) {
			System.err.println("IOException: " + ioe.getMessage());
		}

	}

	public void readLinesInsideNotFound(String fileName) {
		try {

			FileInputStream fis = new FileInputStream(fileName);
			Scanner sc = new Scanner(fis);
			ArrayList<String>notFoundImagesList = new ArrayList<String>();
			ArrayList<String>linesToKeep = new ArrayList<String>();

			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				
				String [] notFoundImages =  line.split("\\*");
				notFoundImagesList.add(notFoundImages[0]);

			}
			System.out.println(notFoundImagesList);
			System.out.println(notFoundImagesList.size());
			
			sc.close();
			
			FileInputStream fisTrain = new FileInputStream("C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\yoga_train.txt");
			Scanner scTrain = new Scanner(fisTrain);
			while (scTrain.hasNextLine()) {
				String line = scTrain.nextLine();
				String SpliiteLine = line.split(",")[0];
				
				if(notFoundImagesList.contains(SpliiteLine)) {
					System.out.println("TOREMOVE----------"+line);
				}else {
					
					linesToKeep.add(line);
				}

			}
			scTrain.close();
			
			for(int i=0;i<linesToKeep.size();i++) {
				try {
					String filename = "C:\\Local Disk D\\Pooja_Thesis\\Yoga_Data-All files\\new_yoga_train.txt";
					FileWriter fw = new FileWriter(filename, true); // the true will append the new data
					fw.write(linesToKeep.get(i) + "\n");// appends the string to the file
					fw.close();
				} catch (IOException ioe) {
					System.err.println("IOException: " + ioe.getMessage());
				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
